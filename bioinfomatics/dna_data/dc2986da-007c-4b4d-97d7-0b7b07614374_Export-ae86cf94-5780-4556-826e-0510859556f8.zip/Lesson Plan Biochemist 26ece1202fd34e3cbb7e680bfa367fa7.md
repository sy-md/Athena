# Lesson Plan Biochemist

- **1.) Chemistry 1**
    1. types of matter 
    2. numerical prefixes Compounds and ISO formula
    3. period table {charges, groups, ect.}
    
    ---
    
    - **unit measurements***
        1. significant figures
            1. dimensional analysis
        2. Sci notation
        3. density
    - **atomic structure***
        1. Ionic Compound 
    - **Stoichiometry@**
        1. **balancing equation**
            - Common Polyatomic (H and OH)
            - types of chemicals
                - *predicting products*
                    - single replacement
                    - double replacement
                    - ect.
            - limit reactions ( **Left overs**)
            - Ionic Equations **(solubility)**
            - enthalpy ( **thermochemistry**)
            - percentage yield (**conclusion to balancing equations**)
                - theoretical yield
        2. **molarity**
            - normality
            - Avogadro's  law
            - limit reactions
    - **Lewis Structure**
        1. formal charges
        2. octet rules 
        3. resonance
        4. hybridization
    - **polarity**
        - rules
        - covalent compounds
        - polar nonpolar
        - electronegativity
        - VESPR
    - thermochemistry
        
        blank
        
- **2.) Chemistry 2**
    1. acids & bases
        1. strong \ weak acids base
        2. acid base reaction
        3. **How to find pH, pOH, H3O+, and OH- STEP BY STEP**
        
        ---
        
    - redox
        - oxidized, reduced, agents
        - equilibria
    - ionic complexes and precipitates
    - inorganic chemistry (do not contain carbon)
    - empirical formulas
    - kinetics
        - rate law & rate
    - titration
        1. acids & bases : C
        2. equivalence point 
        3. rate and reaction
    - ice tables
    - electrochemistry
    - nuclear chemistry
- **3.) Organic Chemistry 1**
    
    [Organic_Chemistry_Survival_Guide.pdf](Lesson%20Plan%20Biochemist%2026ece1202fd34e3cbb7e680bfa367fa7/Organic_Chemistry_Survival_Guide.pdf)
    
    [YouTube](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbTVDZjQtVVh2U3A1ajNFdXNZZkFHLTF1M2JQZ3xBQ3Jtc0trLVppT3dWejhOR0ZjM29xOWdTaHVZV01fSGRJWi1jTlNJQmZ5cDExRmk5VzBDTV85TlF5RGwtZnhvQ0ZUZ0VGUUNob1ZjOHlMclZUS2pINXFXaW5INkY2VlhBNk1yZ2FjWkhqMWtxSlhzTmFxbndyVQ&q=http%3A%2F%2Fbit.ly%2Fg1mechanisms&v=7ufABZvI_yo)
    
    - skeletal structures
        1. **hydrocarbons** 
            1. common Substituents
            2. constitutional isomers
            3. 3 steps naming alkanes
        2. **chiral center & achiral molecular**
        3. **Hydrohalogenation**
            1. markovnikov’s rule
        4. **Hydride Shift & Alkyl Shift**
    
    1. Use structure (ARIO) to predict acid/base strength and position of acid/base equilibrium.
    2. Determine structure of an organic molecule using the molecular formula, IR, MS, and NMR data.
    3. Predict curved arrow mechanisms of organic reactions.
    4. Predict products of an organic reaction based on the mechanism.
    5. Design syntheses of organic molecules
- 4.)**Organic Chemistry 2**

---

# J***obs***

![InkedInkedInkedjobs_biotech_LI.jpg](Lesson%20Plan%20Biochemist%2026ece1202fd34e3cbb7e680bfa367fa7/InkedInkedInkedjobs_biotech_LI.jpg)

Test